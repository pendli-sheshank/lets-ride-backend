package com.letsride.lets_ride_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LetsRideBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(LetsRideBackendApplication.class, args);
	}

}
