package com.letsride.lets_ride_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LetsRideBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
